// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Point2DArray = require('./Point2DArray.js');
let sensor_msgs = _finder('sensor_msgs');
let std_msgs = _finder('std_msgs');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class Object {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.object = null;
      this.id = null;
      this.obj_states = null;
      this.obj_accuracy = null;
      this.feature_point = null;
      this.pose = null;
      this.tool_used_for_detection = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('object')) {
        this.object = initObj.object
      }
      else {
        this.object = new sensor_msgs.msg.RegionOfInterest();
      }
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = new std_msgs.msg.Int32();
      }
      if (initObj.hasOwnProperty('obj_states')) {
        this.obj_states = initObj.obj_states
      }
      else {
        this.obj_states = new std_msgs.msg.String();
      }
      if (initObj.hasOwnProperty('obj_accuracy')) {
        this.obj_accuracy = initObj.obj_accuracy
      }
      else {
        this.obj_accuracy = new std_msgs.msg.Float64();
      }
      if (initObj.hasOwnProperty('feature_point')) {
        this.feature_point = initObj.feature_point
      }
      else {
        this.feature_point = new Point2DArray();
      }
      if (initObj.hasOwnProperty('pose')) {
        this.pose = initObj.pose
      }
      else {
        this.pose = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('tool_used_for_detection')) {
        this.tool_used_for_detection = initObj.tool_used_for_detection
      }
      else {
        this.tool_used_for_detection = new std_msgs.msg.String();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Object
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [object]
    bufferOffset = sensor_msgs.msg.RegionOfInterest.serialize(obj.object, buffer, bufferOffset);
    // Serialize message field [id]
    bufferOffset = std_msgs.msg.Int32.serialize(obj.id, buffer, bufferOffset);
    // Serialize message field [obj_states]
    bufferOffset = std_msgs.msg.String.serialize(obj.obj_states, buffer, bufferOffset);
    // Serialize message field [obj_accuracy]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.obj_accuracy, buffer, bufferOffset);
    // Serialize message field [feature_point]
    bufferOffset = Point2DArray.serialize(obj.feature_point, buffer, bufferOffset);
    // Serialize message field [pose]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.pose, buffer, bufferOffset);
    // Serialize message field [tool_used_for_detection]
    bufferOffset = std_msgs.msg.String.serialize(obj.tool_used_for_detection, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Object
    let len;
    let data = new Object(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [object]
    data.object = sensor_msgs.msg.RegionOfInterest.deserialize(buffer, bufferOffset);
    // Deserialize message field [id]
    data.id = std_msgs.msg.Int32.deserialize(buffer, bufferOffset);
    // Deserialize message field [obj_states]
    data.obj_states = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    // Deserialize message field [obj_accuracy]
    data.obj_accuracy = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    // Deserialize message field [feature_point]
    data.feature_point = Point2DArray.deserialize(buffer, bufferOffset);
    // Deserialize message field [pose]
    data.pose = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [tool_used_for_detection]
    data.tool_used_for_detection = std_msgs.msg.String.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += std_msgs.msg.String.getMessageSize(object.obj_states);
    length += Point2DArray.getMessageSize(object.feature_point);
    length += std_msgs.msg.String.getMessageSize(object.tool_used_for_detection);
    return length + 85;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Object';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '232560d9417be3244e13955b54eafc19';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Header header
    sensor_msgs/RegionOfInterest object
    std_msgs/Int32 id
    std_msgs/String obj_states
    std_msgs/Float64 obj_accuracy
    Point2DArray feature_point
    geometry_msgs/Pose pose
    std_msgs/String tool_used_for_detection
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    # 0: no frame
    # 1: global frame
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/RegionOfInterest
    # This message is used to specify a region of interest within an image.
    #
    # When used to specify the ROI setting of the camera when the image was
    # taken, the height and width fields should either match the height and
    # width fields for the associated image; or height = width = 0
    # indicates that the full resolution image was captured.
    
    uint32 x_offset  # Leftmost pixel of the ROI
                     # (0 if the ROI includes the left edge of the image)
    uint32 y_offset  # Topmost pixel of the ROI
                     # (0 if the ROI includes the top edge of the image)
    uint32 height    # Height of ROI
    uint32 width     # Width of ROI
    
    # True if a distinct rectified ROI should be calculated from the "raw"
    # ROI in this message. Typically this should be False if the full image
    # is captured (ROI not used), and True if a subwindow is captured (ROI
    # used).
    bool do_rectify
    
    ================================================================================
    MSG: std_msgs/Int32
    int32 data
    ================================================================================
    MSG: std_msgs/String
    string data
    
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    ================================================================================
    MSG: hr_msgs/Point2DArray
    Point2D[] points
    
    ================================================================================
    MSG: hr_msgs/Point2D
    float64 x
    float64 y
    
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Object(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.object !== undefined) {
      resolved.object = sensor_msgs.msg.RegionOfInterest.Resolve(msg.object)
    }
    else {
      resolved.object = new sensor_msgs.msg.RegionOfInterest()
    }

    if (msg.id !== undefined) {
      resolved.id = std_msgs.msg.Int32.Resolve(msg.id)
    }
    else {
      resolved.id = new std_msgs.msg.Int32()
    }

    if (msg.obj_states !== undefined) {
      resolved.obj_states = std_msgs.msg.String.Resolve(msg.obj_states)
    }
    else {
      resolved.obj_states = new std_msgs.msg.String()
    }

    if (msg.obj_accuracy !== undefined) {
      resolved.obj_accuracy = std_msgs.msg.Float64.Resolve(msg.obj_accuracy)
    }
    else {
      resolved.obj_accuracy = new std_msgs.msg.Float64()
    }

    if (msg.feature_point !== undefined) {
      resolved.feature_point = Point2DArray.Resolve(msg.feature_point)
    }
    else {
      resolved.feature_point = new Point2DArray()
    }

    if (msg.pose !== undefined) {
      resolved.pose = geometry_msgs.msg.Pose.Resolve(msg.pose)
    }
    else {
      resolved.pose = new geometry_msgs.msg.Pose()
    }

    if (msg.tool_used_for_detection !== undefined) {
      resolved.tool_used_for_detection = std_msgs.msg.String.Resolve(msg.tool_used_for_detection)
    }
    else {
      resolved.tool_used_for_detection = new std_msgs.msg.String()
    }

    return resolved;
    }
};

module.exports = Object;
