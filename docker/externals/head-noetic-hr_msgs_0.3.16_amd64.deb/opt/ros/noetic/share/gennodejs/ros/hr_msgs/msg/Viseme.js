// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Viseme {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.start = null;
      this.duration = null;
      this.rampin = null;
      this.rampout = null;
      this.magnitude = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('start')) {
        this.start = initObj.start
      }
      else {
        this.start = 0.0;
      }
      if (initObj.hasOwnProperty('duration')) {
        this.duration = initObj.duration
      }
      else {
        this.duration = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('rampin')) {
        this.rampin = initObj.rampin
      }
      else {
        this.rampin = 0.0;
      }
      if (initObj.hasOwnProperty('rampout')) {
        this.rampout = initObj.rampout
      }
      else {
        this.rampout = 0.0;
      }
      if (initObj.hasOwnProperty('magnitude')) {
        this.magnitude = initObj.magnitude
      }
      else {
        this.magnitude = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Viseme
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [start]
    bufferOffset = _serializer.float32(obj.start, buffer, bufferOffset);
    // Serialize message field [duration]
    bufferOffset = _serializer.duration(obj.duration, buffer, bufferOffset);
    // Serialize message field [rampin]
    bufferOffset = _serializer.float32(obj.rampin, buffer, bufferOffset);
    // Serialize message field [rampout]
    bufferOffset = _serializer.float32(obj.rampout, buffer, bufferOffset);
    // Serialize message field [magnitude]
    bufferOffset = _serializer.float32(obj.magnitude, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Viseme
    let len;
    let data = new Viseme(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [start]
    data.start = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [duration]
    data.duration = _deserializer.duration(buffer, bufferOffset);
    // Deserialize message field [rampin]
    data.rampin = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [rampout]
    data.rampout = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [magnitude]
    data.magnitude = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    return length + 28;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Viseme';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '14cf9d245726f41d274bb50807bcafde';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    float32 start
    duration duration
    float32 rampin
    float32 rampout
    float32 magnitude
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Viseme(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.start !== undefined) {
      resolved.start = msg.start;
    }
    else {
      resolved.start = 0.0
    }

    if (msg.duration !== undefined) {
      resolved.duration = msg.duration;
    }
    else {
      resolved.duration = {secs: 0, nsecs: 0}
    }

    if (msg.rampin !== undefined) {
      resolved.rampin = msg.rampin;
    }
    else {
      resolved.rampin = 0.0
    }

    if (msg.rampout !== undefined) {
      resolved.rampout = msg.rampout;
    }
    else {
      resolved.rampout = 0.0
    }

    if (msg.magnitude !== undefined) {
      resolved.magnitude = msg.magnitude;
    }
    else {
      resolved.magnitude = 0.0
    }

    return resolved;
    }
};

module.exports = Viseme;
