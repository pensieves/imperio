
"use strict";

let UpdateMotors = require('./UpdateMotors.js')
let GetMode = require('./GetMode.js')
let RunByName = require('./RunByName.js')
let Load = require('./Load.js')
let ChatSession = require('./ChatSession.js')
let SetScene = require('./SetScene.js')
let ChatService = require('./ChatService.js')
let ValidFaceExprs = require('./ValidFaceExprs.js')
let FaceLandmarks = require('./FaceLandmarks.js')
let GetIntent = require('./GetIntent.js')
let Stop = require('./Stop.js')
let Json = require('./Json.js')
let Pause = require('./Pause.js')
let Emotion = require('./Emotion.js')
let Resume = require('./Resume.js')
let SetActuatorsControl = require('./SetActuatorsControl.js')
let MotionManagement = require('./MotionManagement.js')
let MotorStates = require('./MotorStates.js')
let ConfigurableNodes = require('./ConfigurableNodes.js')
let NodeDescription = require('./NodeDescription.js')
let TTSData = require('./TTSData.js')
let AnimationLength = require('./AnimationLength.js')
let EyeState = require('./EyeState.js')
let FaceId = require('./FaceId.js')
let MotorValues = require('./MotorValues.js')
let NodeAction = require('./NodeAction.js')
let UpdateExpressions = require('./UpdateExpressions.js')
let PerformanceCommand = require('./PerformanceCommand.js')
let Current = require('./Current.js')
let SetMode = require('./SetMode.js')
let SetParam = require('./SetParam.js')
let GetAnimationLength = require('./GetAnimationLength.js')
let LoadPerformance = require('./LoadPerformance.js')
let ResetMotors = require('./ResetMotors.js')
let Run = require('./Run.js')
let TTSLength = require('./TTSLength.js')
let SetProperties = require('./SetProperties.js')
let StringArray = require('./StringArray.js')
let NodeConfiguration = require('./NodeConfiguration.js')
let MotorValuesBool = require('./MotorValuesBool.js')
let GetParam = require('./GetParam.js')

module.exports = {
  UpdateMotors: UpdateMotors,
  GetMode: GetMode,
  RunByName: RunByName,
  Load: Load,
  ChatSession: ChatSession,
  SetScene: SetScene,
  ChatService: ChatService,
  ValidFaceExprs: ValidFaceExprs,
  FaceLandmarks: FaceLandmarks,
  GetIntent: GetIntent,
  Stop: Stop,
  Json: Json,
  Pause: Pause,
  Emotion: Emotion,
  Resume: Resume,
  SetActuatorsControl: SetActuatorsControl,
  MotionManagement: MotionManagement,
  MotorStates: MotorStates,
  ConfigurableNodes: ConfigurableNodes,
  NodeDescription: NodeDescription,
  TTSData: TTSData,
  AnimationLength: AnimationLength,
  EyeState: EyeState,
  FaceId: FaceId,
  MotorValues: MotorValues,
  NodeAction: NodeAction,
  UpdateExpressions: UpdateExpressions,
  PerformanceCommand: PerformanceCommand,
  Current: Current,
  SetMode: SetMode,
  SetParam: SetParam,
  GetAnimationLength: GetAnimationLength,
  LoadPerformance: LoadPerformance,
  ResetMotors: ResetMotors,
  Run: Run,
  TTSLength: TTSLength,
  SetProperties: SetProperties,
  StringArray: StringArray,
  NodeConfiguration: NodeConfiguration,
  MotorValuesBool: MotorValuesBool,
  GetParam: GetParam,
};
