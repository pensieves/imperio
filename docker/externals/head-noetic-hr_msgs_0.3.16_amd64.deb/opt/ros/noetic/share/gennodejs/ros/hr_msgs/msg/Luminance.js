// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class Luminance {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.covered = null;
      this.camFlash = null;
      this.sudden_change = null;
      this.room_light = null;
      this.value = null;
      this.perc_covered = null;
    }
    else {
      if (initObj.hasOwnProperty('covered')) {
        this.covered = initObj.covered
      }
      else {
        this.covered = 0;
      }
      if (initObj.hasOwnProperty('camFlash')) {
        this.camFlash = initObj.camFlash
      }
      else {
        this.camFlash = 0;
      }
      if (initObj.hasOwnProperty('sudden_change')) {
        this.sudden_change = initObj.sudden_change
      }
      else {
        this.sudden_change = 0;
      }
      if (initObj.hasOwnProperty('room_light')) {
        this.room_light = initObj.room_light
      }
      else {
        this.room_light = '';
      }
      if (initObj.hasOwnProperty('value')) {
        this.value = initObj.value
      }
      else {
        this.value = 0.0;
      }
      if (initObj.hasOwnProperty('perc_covered')) {
        this.perc_covered = initObj.perc_covered
      }
      else {
        this.perc_covered = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Luminance
    // Serialize message field [covered]
    bufferOffset = _serializer.int8(obj.covered, buffer, bufferOffset);
    // Serialize message field [camFlash]
    bufferOffset = _serializer.int8(obj.camFlash, buffer, bufferOffset);
    // Serialize message field [sudden_change]
    bufferOffset = _serializer.int8(obj.sudden_change, buffer, bufferOffset);
    // Serialize message field [room_light]
    bufferOffset = _serializer.string(obj.room_light, buffer, bufferOffset);
    // Serialize message field [value]
    bufferOffset = _serializer.float32(obj.value, buffer, bufferOffset);
    // Serialize message field [perc_covered]
    bufferOffset = _serializer.float32(obj.perc_covered, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Luminance
    let len;
    let data = new Luminance(null);
    // Deserialize message field [covered]
    data.covered = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [camFlash]
    data.camFlash = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [sudden_change]
    data.sudden_change = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [room_light]
    data.room_light = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [value]
    data.value = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [perc_covered]
    data.perc_covered = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.room_light.length;
    return length + 15;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Luminance';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ebef646506a25472f69fb441a7e93874';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    int8 covered
    int8 camFlash
    int8 sudden_change
    string room_light
    float32 value
    float32 perc_covered
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Luminance(null);
    if (msg.covered !== undefined) {
      resolved.covered = msg.covered;
    }
    else {
      resolved.covered = 0
    }

    if (msg.camFlash !== undefined) {
      resolved.camFlash = msg.camFlash;
    }
    else {
      resolved.camFlash = 0
    }

    if (msg.sudden_change !== undefined) {
      resolved.sudden_change = msg.sudden_change;
    }
    else {
      resolved.sudden_change = 0
    }

    if (msg.room_light !== undefined) {
      resolved.room_light = msg.room_light;
    }
    else {
      resolved.room_light = ''
    }

    if (msg.value !== undefined) {
      resolved.value = msg.value;
    }
    else {
      resolved.value = 0.0
    }

    if (msg.perc_covered !== undefined) {
      resolved.perc_covered = msg.perc_covered;
    }
    else {
      resolved.perc_covered = 0.0
    }

    return resolved;
    }
};

module.exports = Luminance;
