// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let MotionSignal = require('./MotionSignal.js');

//-----------------------------------------------------------

class Motion {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.active = null;
      this.priority = null;
      this.motionSignals = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('active')) {
        this.active = initObj.active
      }
      else {
        this.active = false;
      }
      if (initObj.hasOwnProperty('priority')) {
        this.priority = initObj.priority
      }
      else {
        this.priority = 0;
      }
      if (initObj.hasOwnProperty('motionSignals')) {
        this.motionSignals = initObj.motionSignals
      }
      else {
        this.motionSignals = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Motion
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [active]
    bufferOffset = _serializer.bool(obj.active, buffer, bufferOffset);
    // Serialize message field [priority]
    bufferOffset = _serializer.int32(obj.priority, buffer, bufferOffset);
    // Serialize message field [motionSignals]
    // Serialize the length for message field [motionSignals]
    bufferOffset = _serializer.uint32(obj.motionSignals.length, buffer, bufferOffset);
    obj.motionSignals.forEach((val) => {
      bufferOffset = MotionSignal.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Motion
    let len;
    let data = new Motion(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [active]
    data.active = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [priority]
    data.priority = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [motionSignals]
    // Deserialize array length for message field [motionSignals]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.motionSignals = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.motionSignals[i] = MotionSignal.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.name.length;
    object.motionSignals.forEach((val) => {
      length += MotionSignal.getMessageSize(val);
    });
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Motion';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c38bcee11a21db4d718ead93e77703d3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name         # name of motion
    bool   active       # is motion active
    int32  priority     # priority of motion
    MotionSignal[] motionSignals # state of the motion signals
    
    ================================================================================
    MSG: hr_msgs/MotionSignal
    string  name       # signal name
    bool    isActive   # indicates if node is currently active
    float64 timePassed # time since the 'isActive' label has changed
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Motion(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.active !== undefined) {
      resolved.active = msg.active;
    }
    else {
      resolved.active = false
    }

    if (msg.priority !== undefined) {
      resolved.priority = msg.priority;
    }
    else {
      resolved.priority = 0
    }

    if (msg.motionSignals !== undefined) {
      resolved.motionSignals = new Array(msg.motionSignals.length);
      for (let i = 0; i < resolved.motionSignals.length; ++i) {
        resolved.motionSignals[i] = MotionSignal.Resolve(msg.motionSignals[i]);
      }
    }
    else {
      resolved.motionSignals = []
    }

    return resolved;
    }
};

module.exports = Motion;
