// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class SourceInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.source_id = null;
      this.source_pos = null;
      this.longitude = null;
      this.latitude = null;
      this.source_probability = null;
      this.separation_data = null;
      this.postfiltered_data = null;
    }
    else {
      if (initObj.hasOwnProperty('source_id')) {
        this.source_id = initObj.source_id
      }
      else {
        this.source_id = 0;
      }
      if (initObj.hasOwnProperty('source_pos')) {
        this.source_pos = initObj.source_pos
      }
      else {
        this.source_pos = new geometry_msgs.msg.Point();
      }
      if (initObj.hasOwnProperty('longitude')) {
        this.longitude = initObj.longitude
      }
      else {
        this.longitude = 0.0;
      }
      if (initObj.hasOwnProperty('latitude')) {
        this.latitude = initObj.latitude
      }
      else {
        this.latitude = 0.0;
      }
      if (initObj.hasOwnProperty('source_probability')) {
        this.source_probability = initObj.source_probability
      }
      else {
        this.source_probability = 0.0;
      }
      if (initObj.hasOwnProperty('separation_data')) {
        this.separation_data = initObj.separation_data
      }
      else {
        this.separation_data = [];
      }
      if (initObj.hasOwnProperty('postfiltered_data')) {
        this.postfiltered_data = initObj.postfiltered_data
      }
      else {
        this.postfiltered_data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SourceInfo
    // Serialize message field [source_id]
    bufferOffset = _serializer.uint32(obj.source_id, buffer, bufferOffset);
    // Serialize message field [source_pos]
    bufferOffset = geometry_msgs.msg.Point.serialize(obj.source_pos, buffer, bufferOffset);
    // Serialize message field [longitude]
    bufferOffset = _serializer.float32(obj.longitude, buffer, bufferOffset);
    // Serialize message field [latitude]
    bufferOffset = _serializer.float32(obj.latitude, buffer, bufferOffset);
    // Serialize message field [source_probability]
    bufferOffset = _serializer.float32(obj.source_probability, buffer, bufferOffset);
    // Serialize message field [separation_data]
    bufferOffset = _arraySerializer.float32(obj.separation_data, buffer, bufferOffset, null);
    // Serialize message field [postfiltered_data]
    bufferOffset = _arraySerializer.float32(obj.postfiltered_data, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SourceInfo
    let len;
    let data = new SourceInfo(null);
    // Deserialize message field [source_id]
    data.source_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [source_pos]
    data.source_pos = geometry_msgs.msg.Point.deserialize(buffer, bufferOffset);
    // Deserialize message field [longitude]
    data.longitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [latitude]
    data.latitude = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [source_probability]
    data.source_probability = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [separation_data]
    data.separation_data = _arrayDeserializer.float32(buffer, bufferOffset, null)
    // Deserialize message field [postfiltered_data]
    data.postfiltered_data = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.separation_data.length;
    length += 4 * object.postfiltered_data.length;
    return length + 48;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/SourceInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '94f909a2797d50c0ca7dbb707ce66302';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #Tracked source information
    uint32 source_id
    geometry_msgs/Point source_pos
    float32 longitude   # In degrees
    float32 latitude    # In degrees 
    float32 source_probability
    float32[] separation_data # Separation data (audio stream)
    float32[] postfiltered_data # Postfiltered data (audio stream)
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SourceInfo(null);
    if (msg.source_id !== undefined) {
      resolved.source_id = msg.source_id;
    }
    else {
      resolved.source_id = 0
    }

    if (msg.source_pos !== undefined) {
      resolved.source_pos = geometry_msgs.msg.Point.Resolve(msg.source_pos)
    }
    else {
      resolved.source_pos = new geometry_msgs.msg.Point()
    }

    if (msg.longitude !== undefined) {
      resolved.longitude = msg.longitude;
    }
    else {
      resolved.longitude = 0.0
    }

    if (msg.latitude !== undefined) {
      resolved.latitude = msg.latitude;
    }
    else {
      resolved.latitude = 0.0
    }

    if (msg.source_probability !== undefined) {
      resolved.source_probability = msg.source_probability;
    }
    else {
      resolved.source_probability = 0.0
    }

    if (msg.separation_data !== undefined) {
      resolved.separation_data = msg.separation_data;
    }
    else {
      resolved.separation_data = []
    }

    if (msg.postfiltered_data !== undefined) {
      resolved.postfiltered_data = msg.postfiltered_data;
    }
    else {
      resolved.postfiltered_data = []
    }

    return resolved;
    }
};

module.exports = SourceInfo;
