// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ChatResponse = require('./ChatResponse.js');

//-----------------------------------------------------------

class ChatResponses {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.responses = null;
    }
    else {
      if (initObj.hasOwnProperty('responses')) {
        this.responses = initObj.responses
      }
      else {
        this.responses = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ChatResponses
    // Serialize message field [responses]
    // Serialize the length for message field [responses]
    bufferOffset = _serializer.uint32(obj.responses.length, buffer, bufferOffset);
    obj.responses.forEach((val) => {
      bufferOffset = ChatResponse.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ChatResponses
    let len;
    let data = new ChatResponses(null);
    // Deserialize message field [responses]
    // Deserialize array length for message field [responses]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.responses = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.responses[i] = ChatResponse.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.responses.forEach((val) => {
      length += ChatResponse.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/ChatResponses';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'fe9fe689613063abc298bf361630109f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ChatResponse[] responses
    
    ================================================================================
    MSG: hr_msgs/ChatResponse
    string text
    string lang
    string label
    string request_id
    string agent_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ChatResponses(null);
    if (msg.responses !== undefined) {
      resolved.responses = new Array(msg.responses.length);
      for (let i = 0; i < resolved.responses.length; ++i) {
        resolved.responses[i] = ChatResponse.Resolve(msg.responses[i]);
      }
    }
    else {
      resolved.responses = []
    }

    return resolved;
    }
};

module.exports = ChatResponses;
