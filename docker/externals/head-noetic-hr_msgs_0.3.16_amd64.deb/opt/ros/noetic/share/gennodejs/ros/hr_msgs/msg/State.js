// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Face = require('./Face.js');
let SalientPoint = require('./SalientPoint.js');

//-----------------------------------------------------------

class State {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.ts = null;
      this.faces = null;
      this.poses = null;
      this.salientpoints = null;
    }
    else {
      if (initObj.hasOwnProperty('ts')) {
        this.ts = initObj.ts
      }
      else {
        this.ts = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('faces')) {
        this.faces = initObj.faces
      }
      else {
        this.faces = [];
      }
      if (initObj.hasOwnProperty('poses')) {
        this.poses = initObj.poses
      }
      else {
        this.poses = [];
      }
      if (initObj.hasOwnProperty('salientpoints')) {
        this.salientpoints = initObj.salientpoints
      }
      else {
        this.salientpoints = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type State
    // Serialize message field [ts]
    bufferOffset = _serializer.time(obj.ts, buffer, bufferOffset);
    // Serialize message field [faces]
    // Serialize the length for message field [faces]
    bufferOffset = _serializer.uint32(obj.faces.length, buffer, bufferOffset);
    obj.faces.forEach((val) => {
      bufferOffset = Face.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [poses]
    // Serialize the length for message field [poses]
    bufferOffset = _serializer.uint32(obj.poses.length, buffer, bufferOffset);
    obj.poses.forEach((val) => {
      bufferOffset = Face.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [salientpoints]
    // Serialize the length for message field [salientpoints]
    bufferOffset = _serializer.uint32(obj.salientpoints.length, buffer, bufferOffset);
    obj.salientpoints.forEach((val) => {
      bufferOffset = SalientPoint.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type State
    let len;
    let data = new State(null);
    // Deserialize message field [ts]
    data.ts = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [faces]
    // Deserialize array length for message field [faces]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.faces = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.faces[i] = Face.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [poses]
    // Deserialize array length for message field [poses]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.poses = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.poses[i] = Face.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [salientpoints]
    // Deserialize array length for message field [salientpoints]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.salientpoints = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.salientpoints[i] = SalientPoint.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.faces.forEach((val) => {
      length += Face.getMessageSize(val);
    });
    object.poses.forEach((val) => {
      length += Face.getMessageSize(val);
    });
    length += 40 * object.salientpoints.length;
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/State';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '92dbf41123a9f80bb94fa092804b770a';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    time ts
    Face[] faces
    Face[] poses
    SalientPoint[] salientpoints
    ================================================================================
    MSG: hr_msgs/Face
    float32 confidence
    uint64 fsdk_id
    uint64 uid
    string first_name
    string last_name
    string formal_name
    bool is_female
    bool is_speaking
    geometry_msgs/Point position
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: hr_msgs/SalientPoint
    geometry_msgs/Point position
    float32 motion
    float32 umap
    float32 vmap
    float32 contrast
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new State(null);
    if (msg.ts !== undefined) {
      resolved.ts = msg.ts;
    }
    else {
      resolved.ts = {secs: 0, nsecs: 0}
    }

    if (msg.faces !== undefined) {
      resolved.faces = new Array(msg.faces.length);
      for (let i = 0; i < resolved.faces.length; ++i) {
        resolved.faces[i] = Face.Resolve(msg.faces[i]);
      }
    }
    else {
      resolved.faces = []
    }

    if (msg.poses !== undefined) {
      resolved.poses = new Array(msg.poses.length);
      for (let i = 0; i < resolved.poses.length; ++i) {
        resolved.poses[i] = Face.Resolve(msg.poses[i]);
      }
    }
    else {
      resolved.poses = []
    }

    if (msg.salientpoints !== undefined) {
      resolved.salientpoints = new Array(msg.salientpoints.length);
      for (let i = 0; i < resolved.salientpoints.length; ++i) {
        resolved.salientpoints[i] = SalientPoint.Resolve(msg.salientpoints[i]);
      }
    }
    else {
      resolved.salientpoints = []
    }

    return resolved;
    }
};

module.exports = State;
