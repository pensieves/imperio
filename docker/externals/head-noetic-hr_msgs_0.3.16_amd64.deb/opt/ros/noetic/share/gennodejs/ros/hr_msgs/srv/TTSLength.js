// Auto-generated. Do not edit!

// (in-package hr_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class TTSLengthRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.txt = null;
      this.lang = null;
    }
    else {
      if (initObj.hasOwnProperty('txt')) {
        this.txt = initObj.txt
      }
      else {
        this.txt = '';
      }
      if (initObj.hasOwnProperty('lang')) {
        this.lang = initObj.lang
      }
      else {
        this.lang = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSLengthRequest
    // Serialize message field [txt]
    bufferOffset = _serializer.string(obj.txt, buffer, bufferOffset);
    // Serialize message field [lang]
    bufferOffset = _serializer.string(obj.lang, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSLengthRequest
    let len;
    let data = new TTSLengthRequest(null);
    // Deserialize message field [txt]
    data.txt = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lang]
    data.lang = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.txt.length;
    length += object.lang.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/TTSLengthRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8cbcfece38fa04d1eaadb06bee64ba2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string txt
    string lang
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSLengthRequest(null);
    if (msg.txt !== undefined) {
      resolved.txt = msg.txt;
    }
    else {
      resolved.txt = ''
    }

    if (msg.lang !== undefined) {
      resolved.lang = msg.lang;
    }
    else {
      resolved.lang = ''
    }

    return resolved;
    }
};

class TTSLengthResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.length = null;
    }
    else {
      if (initObj.hasOwnProperty('length')) {
        this.length = initObj.length
      }
      else {
        this.length = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type TTSLengthResponse
    // Serialize message field [length]
    bufferOffset = _serializer.float32(obj.length, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type TTSLengthResponse
    let len;
    let data = new TTSLengthResponse(null);
    // Deserialize message field [length]
    data.length = _deserializer.float32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'hr_msgs/TTSLengthResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '30516591bd33c945cbc4d8d225f8022b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 length
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new TTSLengthResponse(null);
    if (msg.length !== undefined) {
      resolved.length = msg.length;
    }
    else {
      resolved.length = 0.0
    }

    return resolved;
    }
};

module.exports = {
  Request: TTSLengthRequest,
  Response: TTSLengthResponse,
  md5sum() { return '1d9d61cca01d099b421f450f3266e6fd'; },
  datatype() { return 'hr_msgs/TTSLength'; }
};
