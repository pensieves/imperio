
"use strict";

let Objects = require('./Objects.js');
let MotionSignal = require('./MotionSignal.js');
let pau = require('./pau.js');
let Luminance = require('./Luminance.js');
let Face = require('./Face.js');
let ChatMessage = require('./ChatMessage.js');
let SourceInfo = require('./SourceInfo.js');
let MotorStateList = require('./MotorStateList.js');
let MotorCommand = require('./MotorCommand.js');
let SomaStates = require('./SomaStates.js');
let State = require('./State.js');
let Viseme = require('./Viseme.js');
let Trackers = require('./Trackers.js');
let faces = require('./faces.js');
let TTS = require('./TTS.js');
let Point2DArray = require('./Point2DArray.js');
let PeopleFaces = require('./PeopleFaces.js');
let PlayAnimation = require('./PlayAnimation.js');
let VADMessage = require('./VADMessage.js');
let Object = require('./Object.js');
let GetAPIVersion = require('./GetAPIVersion.js');
let PiFace = require('./PiFace.js');
let audiodata = require('./audiodata.js');
let SoulTalkChat = require('./SoulTalkChat.js');
let Assign = require('./Assign.js');
let Motions = require('./Motions.js');
let ChatResponse = require('./ChatResponse.js');
let SetExpression = require('./SetExpression.js');
let TargetPosture = require('./TargetPosture.js');
let CurrentFrame = require('./CurrentFrame.js');
let Faces = require('./Faces.js');
let FaceEvent = require('./FaceEvent.js');
let PiVisionFace = require('./PiVisionFace.js');
let PeopleFace = require('./PeopleFace.js');
let Visemes = require('./Visemes.js');
let ManyEarsTrackedAudioSource = require('./ManyEarsTrackedAudioSource.js');
let Event = require('./Event.js');
let f_id = require('./f_id.js');
let faces_ids = require('./faces_ids.js');
let Tracker = require('./Tracker.js');
let SalientPoint = require('./SalientPoint.js');
let HeadFun = require('./HeadFun.js');
let Hand = require('./Hand.js');
let Gestures = require('./Gestures.js');
let BlinkCycle = require('./BlinkCycle.js');
let ChatResponses = require('./ChatResponses.js');
let Point2D = require('./Point2D.js');
let PointHead = require('./PointHead.js');
let FSValues = require('./FSValues.js');
let Status = require('./Status.js');
let FSShapekeys = require('./FSShapekeys.js');
let Stroke = require('./Stroke.js');
let PiVisionFaces = require('./PiVisionFaces.js');
let Strokes = require('./Strokes.js');
let MotorState = require('./MotorState.js');
let Target = require('./Target.js');
let facebox = require('./facebox.js');
let Features = require('./Features.js');
let SetGestureClip = require('./SetGestureClip.js');
let AudioStream = require('./AudioStream.js');
let SaccadeCycle = require('./SaccadeCycle.js');
let Doa = require('./Doa.js');
let Feature = require('./Feature.js');
let SourceInfoWithCovariance = require('./SourceInfoWithCovariance.js');
let SetAnimation = require('./SetAnimation.js');
let Gesture = require('./Gesture.js');
let TTSItem = require('./TTSItem.js');
let FSShapekey = require('./FSShapekey.js');
let Vision = require('./Vision.js');
let SomaState = require('./SomaState.js');
let Motion = require('./Motion.js');
let ForgetAll = require('./ForgetAll.js');
let MakeFaceExpr = require('./MakeFaceExpr.js');
let Forget = require('./Forget.js');
let targets = require('./targets.js');

module.exports = {
  Objects: Objects,
  MotionSignal: MotionSignal,
  pau: pau,
  Luminance: Luminance,
  Face: Face,
  ChatMessage: ChatMessage,
  SourceInfo: SourceInfo,
  MotorStateList: MotorStateList,
  MotorCommand: MotorCommand,
  SomaStates: SomaStates,
  State: State,
  Viseme: Viseme,
  Trackers: Trackers,
  faces: faces,
  TTS: TTS,
  Point2DArray: Point2DArray,
  PeopleFaces: PeopleFaces,
  PlayAnimation: PlayAnimation,
  VADMessage: VADMessage,
  Object: Object,
  GetAPIVersion: GetAPIVersion,
  PiFace: PiFace,
  audiodata: audiodata,
  SoulTalkChat: SoulTalkChat,
  Assign: Assign,
  Motions: Motions,
  ChatResponse: ChatResponse,
  SetExpression: SetExpression,
  TargetPosture: TargetPosture,
  CurrentFrame: CurrentFrame,
  Faces: Faces,
  FaceEvent: FaceEvent,
  PiVisionFace: PiVisionFace,
  PeopleFace: PeopleFace,
  Visemes: Visemes,
  ManyEarsTrackedAudioSource: ManyEarsTrackedAudioSource,
  Event: Event,
  f_id: f_id,
  faces_ids: faces_ids,
  Tracker: Tracker,
  SalientPoint: SalientPoint,
  HeadFun: HeadFun,
  Hand: Hand,
  Gestures: Gestures,
  BlinkCycle: BlinkCycle,
  ChatResponses: ChatResponses,
  Point2D: Point2D,
  PointHead: PointHead,
  FSValues: FSValues,
  Status: Status,
  FSShapekeys: FSShapekeys,
  Stroke: Stroke,
  PiVisionFaces: PiVisionFaces,
  Strokes: Strokes,
  MotorState: MotorState,
  Target: Target,
  facebox: facebox,
  Features: Features,
  SetGestureClip: SetGestureClip,
  AudioStream: AudioStream,
  SaccadeCycle: SaccadeCycle,
  Doa: Doa,
  Feature: Feature,
  SourceInfoWithCovariance: SourceInfoWithCovariance,
  SetAnimation: SetAnimation,
  Gesture: Gesture,
  TTSItem: TTSItem,
  FSShapekey: FSShapekey,
  Vision: Vision,
  SomaState: SomaState,
  Motion: Motion,
  ForgetAll: ForgetAll,
  MakeFaceExpr: MakeFaceExpr,
  Forget: Forget,
  targets: targets,
};
