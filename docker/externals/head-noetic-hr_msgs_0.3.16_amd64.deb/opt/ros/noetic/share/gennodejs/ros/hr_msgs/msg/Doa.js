// Auto-generated. Do not edit!

// (in-package hr_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Doa {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.DOA = null;
    }
    else {
      if (initObj.hasOwnProperty('DOA')) {
        this.DOA = initObj.DOA
      }
      else {
        this.DOA = new std_msgs.msg.Float64();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Doa
    // Serialize message field [DOA]
    bufferOffset = std_msgs.msg.Float64.serialize(obj.DOA, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Doa
    let len;
    let data = new Doa(null);
    // Deserialize message field [DOA]
    data.DOA = std_msgs.msg.Float64.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'hr_msgs/Doa';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f23d9f55162837fc1d7c32f4d129c59c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #This message is used to publish DOA from an Audio Detecting Device
    #Most recently, it was used to publish voice activated doa from Respeaker Core v2
    
    std_msgs/Float64 DOA
    
    ================================================================================
    MSG: std_msgs/Float64
    float64 data
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Doa(null);
    if (msg.DOA !== undefined) {
      resolved.DOA = std_msgs.msg.Float64.Resolve(msg.DOA)
    }
    else {
      resolved.DOA = new std_msgs.msg.Float64()
    }

    return resolved;
    }
};

module.exports = Doa;
